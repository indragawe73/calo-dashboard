export { default as AdminTablePage } from './AdminTablePage';
export { default as RegisterPage } from './RegisterPage';
