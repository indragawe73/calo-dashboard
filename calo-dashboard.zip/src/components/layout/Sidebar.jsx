import { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { useLocation, Link } from 'react-router-dom';
import { 
  Home,
  Users,
  Shield,
  Star,
  FileText,
  Settings,
  BookOpen,
  Clipboard,
  MessageSquare,
  Calendar,
  Code,
  BarChart3,
  MapPin,
  Package,
  Boxes,
  Tag,
  Palette,
  Layers,
  Shapes,
  Globe,
  Building,
  Target,
  ChevronDown,
  ChevronRight,
  X,
  UserPlus
} from 'lucide-react';
import { selectSidebarCollapsed, selectSidebarOpen, setSidebarOpen } from '../../store/slices/uiSlice';
import { selectCurrentUser } from '../../store/slices/authSlice';
import './Sidebar.scss';

const Sidebar = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const location = useLocation();
  const sidebarCollapsed = useSelector(selectSidebarCollapsed);
  const sidebarOpen = useSelector(selectSidebarOpen);
  const currentUser = useSelector(selectCurrentUser);
  
  const [expandedMenus, setExpandedMenus] = useState({});

  // Menu structure with icons and nested items
  const getMenuItems = () => {
    const baseItems = [
      // {
      //   id: 'dashboard',
      //   label: t('navigation.dashboard'),
      //   icon: <Home size={20} />,
      //   path: '/dashboard',
      // },
      // {
      //   id: 'administration',
      //   label: t('navigation.administration'),
      //   icon: <Settings size={20} />,
      //   path: '/dashboard/administration/site-details',
      // },
      {
        id: 'image',
        // label: 'Image List',
        label: t('navigation.image'),
        icon: <FileText size={20} />,
        path: '/dashboard/image-list',
      },
      // {
      //   id: 'procedure',
      //   label: t('navigation.procedure'),
      //   icon: <Clipboard size={20} />,
      //   path: '/dashboard/procedure/sops'
      // },
      // {
      //   id: 'standard-code',
      //   label: t('navigation.standardCode'),
      //   icon: <Code size={20} />,
      //   path: '/dashboard/standard-code/chart-of-accounts',
      // },
      // {
      //   id: 'form-report',
      //   label: t('navigation.formReport'),
      //   icon: <FileText size={20} />,
      //   path: '/dashboard/form-report/forms',
      // },
    ];

    // Add admin-only menu items
    if (currentUser?.role === 'admin') {
      baseItems.push({
        id: 'register',
        label: t('navigation.registerAccount'),
        icon: <UserPlus size={20} />,
        path: '/dashboard/administration/register',
      });
    }

    return baseItems;
  };

  const menuItems = getMenuItems();

  // Close sidebar on mobile when clicking outside
  const handleOverlayClick = () => {
    dispatch(setSidebarOpen(false));
  };

  // Toggle menu expansion
  const toggleMenu = (menuId) => {
    setExpandedMenus(prev => ({
      ...prev,
      [menuId]: !prev[menuId],
    }));
  };

  // Check if current path matches menu item
  const isActiveMenuItem = useCallback((item) => {
    if (item.path) {
      return location.pathname === item.path;
    }
    if (item.children) {
      return item.children.some(child => isActiveMenuItem(child));
    }
    return false;
  }, [location.pathname]);

  // Auto-expand menu if it contains active item
  useEffect(() => {
    const findActiveMenu = (items) => {
      items.forEach(item => {
        if (item.children) {
          const hasActiveChild = item.children.some(child => isActiveMenuItem(child));
          if (hasActiveChild) {
            setExpandedMenus(prev => ({ ...prev, [item.id]: true }));
          }
          findActiveMenu(item.children);
        }
      });
    };

    findActiveMenu(menuItems);
  }, [location.pathname, menuItems, isActiveMenuItem]);

  // Render menu item
  const renderMenuItem = (item, level = 0) => {
    const isActive = isActiveMenuItem(item);
    const isExpanded = expandedMenus[item.id];
    const hasChildren = item.children && item.children.length > 0;

    const itemClasses = [
      'sidebar__menu-item',
      `sidebar__menu-item--level-${level}`,
      isActive && 'sidebar__menu-item--active',
      hasChildren && 'sidebar__menu-item--has-children',
      isExpanded && 'sidebar__menu-item--expanded',
    ].filter(Boolean).join(' ');

    const content = (
      <>
        <div className="sidebar__menu-item-content">
          {item.icon && (
            <span className="sidebar__menu-item-icon">
              {item.icon}
            </span>
          )}
          <span className="sidebar__menu-item-text">
            {item.label}
          </span>
        </div>
        {hasChildren && (
          <span className="sidebar__menu-item-arrow">
            {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
          </span>
        )}
      </>
    );

    return (
      <div key={item.id} className="sidebar__menu-group">
        {item.path ? (
          <Link
            to={item.path}
            className={itemClasses}
            data-tooltip={item.label}
            onClick={() => window.innerWidth < 1024 && dispatch(setSidebarOpen(false))}
          >
            {content}
          </Link>
        ) : (
          <button
            className={itemClasses}
            data-tooltip={item.label}
            onClick={() => hasChildren && toggleMenu(item.id)}
            type="button"
          >
            {content}
          </button>
        )}
        
        {hasChildren && isExpanded && (
          <div className="sidebar__submenu">
            {item.children.map(child => renderMenuItem(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  const sidebarClasses = [
    'sidebar',
    sidebarCollapsed && 'sidebar--collapsed',
    sidebarOpen && 'sidebar--open',
  ].filter(Boolean).join(' ');

  return (
    <>
      <aside className={sidebarClasses}>
        <div className="sidebar__header">
          <div className="sidebar__logo">
            {/* <div className="sidebar__logo-icon">📚</div> */}
            <div className="sidebar__logo-text">
              <div className="sidebar__logo-title">C A L O</div>
              <div className="sidebar__logo-subtitle">Dashboard</div>
            </div>
          </div>
          
          {/* Mobile close button */}
          <button
            className="sidebar__close"
            onClick={() => dispatch(setSidebarOpen(false))}
          >
            <X size={20} />
          </button>
        </div>

        <nav className="sidebar__nav">
          <div className="sidebar__menu">
            {menuItems.map(item => renderMenuItem(item))}
          </div>
        </nav>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="sidebar__overlay" onClick={handleOverlayClick} />
      )}
    </>
  );
};

export default Sidebar;
